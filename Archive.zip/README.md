# Football Predictions (EPL, La Liga, UCL)

This project builds 1/X/2 predictions using API-Football data (fixtures, standings, injuries, lineups when available), with odds prior blending and base-rate calibration. It also supports backtesting-based calibration.

## Quick start
1. Create `config.yaml` from `config.example.yaml`.
2. Set your API key in env:

```bash
export API_FOOTBALL_KEY="YOUR_KEY"
```

3. Install deps:

```bash
pip install -r requirements.txt
```

4. Run lookup to confirm league IDs:

```bash
python -m src.main lookup-league --name "Premier League" --country "England"
```

5. Predict today:

```bash
python -m src.main predict --date today
```

## Notes
- Lineups are often available only close to kickoff; the model uses them if present.
- Injuries are used as a small penalty; you can tune weights in `config.yaml`.
- Odds blending is controlled by `weights.odds_prior` and `odds.enabled` in `config.yaml`.
- Base-rate calibration is controlled by `weights.calibration_blend`.
- Lineup position weights can be tuned via `weights.lineup_position_weights`.

## Backtest + Calibration
Run backtesting over prior seasons to build league-specific calibration:

```bash
python -m src.main backtest --seasons 3
```

This writes `data/calibration.json`, which is used automatically if `calibration.enabled: true`. Calibration is applied by strength buckets (home_strong / even / away_strong).
